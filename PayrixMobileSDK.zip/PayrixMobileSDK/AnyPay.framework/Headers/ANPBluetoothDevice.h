//
//  ANPBluetoothDevice.h
//  AnyPay
//
//  Created by Ankit Gupta on 19/01/18.
//  Copyright © 2018 Dan McCann. All rights reserved.
//

#import <CoreBluetooth/CoreBluetooth.h>

@interface ANPBluetoothDevice : CBPeripheral

@end
